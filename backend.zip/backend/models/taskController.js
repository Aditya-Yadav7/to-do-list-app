// backend/controllers/taskController.js
import Task from '../models/Task.js';

export const getTasks = async (req, res) => {
  const tasks = await Task.find({ userId: req.user._id });
  res.json(tasks);
};

export const createTask = async (req, res) => {
  const task = new Task({ ...req.body, userId: req.user._id });
  const savedTask = await task.save();
  res.status(201).json(savedTask);
};

export const updateTask = async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (task && task.userId.equals(req.user._id)) {
    task.text = req.body.text || task.text;
    task.isCompleted = req.body.isCompleted || task.isCompleted;
    task.priority = req.body.priority || task.priority;
    task.dueDate = req.body.dueDate || task.dueDate;
    const updatedTask = await task.save();
    res.json(updatedTask);
  } else {
    res.status(404).json({ message: 'Task not found' });
  }
};

export const deleteTask = async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (task && task.userId.equals(req.user._id)) {
    await task.remove();
    res.json({ message: 'Task deleted' });
  } else {
    res.status(404).json({ message: 'Task not found' });
  }
};
